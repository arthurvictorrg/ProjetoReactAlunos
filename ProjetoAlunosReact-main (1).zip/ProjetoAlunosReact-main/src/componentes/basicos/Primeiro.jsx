import React from "react";

export default () => {
    return (
        <div>
            Ola Mundo!
        </div>
    )
}
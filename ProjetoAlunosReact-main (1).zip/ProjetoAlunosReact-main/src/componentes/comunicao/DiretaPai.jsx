import React from "react";
import DiretaFilho from "./DiretaFilho";

export default props => {
    return (
        <React.Fragment>
            <DiretaFilho titulo="Ola Filho"/>
        </React.Fragment>
    )
}
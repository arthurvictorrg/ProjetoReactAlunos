import React from "react";

export default props => {
    return (
       <span>{props.titulo}</span>
    )
}
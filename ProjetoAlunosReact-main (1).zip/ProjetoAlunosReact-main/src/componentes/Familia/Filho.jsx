import React from "react";

export default props => {
    return (
        <div>
            <span>{props.nome} <strong>{props.sobrenome}</strong></span>
        </div>
    )
}
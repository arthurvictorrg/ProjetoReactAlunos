export default [
    {id: 1, nome: "Aluno Um", nota: 7.0},
    {id: 2, nome: "Aluno Dois", nota: 7.0},
    {id: 3, nome: "Aluno Tres", nota: 7.0},
    {id: 4, nome: "Aluno Quatro", nota: 7.0}

]
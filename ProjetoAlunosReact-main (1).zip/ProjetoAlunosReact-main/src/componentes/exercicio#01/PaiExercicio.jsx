import React from "react";
import Filho from "./Filho";

export default props => {
    return (
        <React.Fragment>
            <Filho titulo="Ola Filho"/>
        </React.Fragment>
    )
}